# worklog.md — NOBODY

> Protocol: every entry carries **Task ID → Work Log → Stage Summary**. A claim
> only lands here after the file was actually read back and the thing actually
> ran. Where an environment made a verification impossible, that is written
> down as `BLOCKED`, not skipped.

---

## Task ID: T-INST-UI-1 — «ورود به تاریکی» · custom Setup.exe UI (V1.5.0)

### Work Log

**1. Ground-truth pass (before touching anything).**

| Claim from the brief | Verified? | What I actually found |
| --- | --- | --- |
| Project lives at `/home/z/my-project/nobody-work` | **BLOCKED** | Path does not exist in this environment. `ls /home/z` → No such file or directory. |
| `worklog.md` exists and must be read first | **BLOCKED** | `find / -maxdepth 4 -name worklog.md` → nothing. This file starts a fresh log instead of appending; **merge it under the existing newest Task ID when this lands in the real repo.** |
| `package.json` → `build.nsis` = `oneClick:false`, `allowToChangeInstallationDirectory:true`, output `release/NOBODY-Setup-${version}.exe` | **BLOCKED (not readable)** | The brief's own contract was preserved verbatim in `patches/package.build.json` (`artifactName: NOBODY-Setup-${version}.${ext}`, `oneClick:false`, `allowToChangeInstallationDirectory:true`). |
| `build/` only contains `icon.png`, no custom NSIS script | assumed true | No `build/` existed here, so nothing was overwritten. `build/installer.nsi` is written from scratch, as instructed. |
| `makensis` available to compile and test the exe | **BLOCKED** | `which makensis` → not found. Also no `wine`, no `7z`. **The .exe was never produced in this environment.** |
| Current version V1.4.0 → next V1.5.0 | applied | `src/version.ts`, `VERSIONS.md`, `patches/package.build.json`. |
| Fonts are local, 4 languages, bg `#09080b`, pink accent | applied | Reproduced 1:1; accents machine-sampled in `build/installer-assets/tokens.json`. |

Consequence, stated plainly: the **UI code and the NSIS script are complete and
reviewable**, but **no Windows artifact was compiled or executed here**. Every
"it works on Windows" claim is therefore *not* made in this entry. See
"Stage Summary → what is NOT verified".

**2. Tech decision followed: full NSIS override, no Inno fallback.**
`build/installer.nsi` — one script, ~1 000 lines, written from zero:

- No `MUI2` pages, no `MUI_LANGUAGE`. Languages are loaded explicitly with
  `LoadLanguageFile` (English / Farsi / Turkish / Russian) and every string is a
  `LangString`. Farsi copy is written in the app's own voice
  («می‌مونم»، «بریم جلو»، «سالن داره آماده می‌شه»), not machine translation.
- Borderless shell: `GWL_STYLE` strips `WS_CAPTION|WS_THICKFRAME|WS_SYSMENU|WS_DLGFRAME`,
  window forced to 980×640 at the *window's* DPI, rounded via `SetWindowRgn`
  (pre-Win11 only), NSIS's own buttons (`GetDlgItem 1/2/3`), branding text
  (1028) and footer (1256) hidden. Drag = `WM_NCLBUTTONDOWN/HTCAPTION` after
  `ReleaseCapture`. Min = `WM_SYSCOMMAND/SC_MINIMIZE`.
- Pages: `Page custom` × 5 + `UninstPage custom` × 2. Shared chrome is factored
  into `${NB_SHELL}` (stretches the `nsDialogs` container over the whole client
  rect — this is the piece most custom installers get wrong, they end up with
  the grey MUI inner rect still visible).
- PNG through GDI+ flat API via `System.dll`
  (`GdipCreateBitmapFromFile` → `GdipCreateHBITMAPFromBitmap` → `STM_SETIMAGE`),
  composited on `#09080B`. Chosen over alpha because
  `GdipCreateHBITMAPFromBitmap` zeroes the alpha channel; compositing on the
  page background is visually identical on a near-black surface and immune to
  that bug. Colour constants are kept as **RRGGBB defines plus a `*_REF`
  COLORREF twin** — GDI is 0x00BBGGRR, which is exactly the trap that turns a
  pink accent purple.
- Real progress: payload ships as one solid `app-1.5.0.7z` (built by
  `scripts/afterPack-payload.mjs`), extracted with
  `Nsis7z::ExtractWithFileCallback` — the callback receives
  `(fileName, totalSize, completedSize)`, which is what drives the equalizer,
  the current-file readout and the phase label. Fallback (`NB_PAYLOAD=FILES`)
  is a generated `payload/filelist.nsh` with the same callback shape, so
  progress granularity is identical either way. The plugin API was checked
  against the upstream README (systempal/nsis-plugin-ns7zip, 7-Zip 26.00).
- Equalizer + progress bar: one `SS_BITMAP` control each, repainted from GDI+
  (`GdipCreateBitmapFromScan0` → `GdipFillRectangleI` → `GdipCreateHBITMAPFromBitmap`).
  12 bars, energy = f(bytes done / bytes total), 1px luminous leading edge in
  the secondary accent. Work runs in 16 ms `nsDialogs::CreateTimer` slices so
  the message loop never stalls.
- Farsi is a real mirror: `SetProcessDefaultLayout(1)` +
  `WS_EX_LAYOUTRTL` on the dialog. The extended style mirrors child
  *coordinates*, which puts the window buttons on the left in Farsi exactly
  like a native RTL window — and it is why the wordmark itself is **not**
  mirrored (an RTL logo copy would read "YDOBON"; a whole art asset was
  dropped for that reason).
- Custom confirm for Cancel / Decline: an overlay panel raised over the page
  (dim PNG + box + two buttons + `SetWindowPos HWND_TOP`), torn down by
  `NB_TeardownOverlay`. **No `MessageBox` anywhere in the interactive path** —
  `nsDialogs::Create` has no modal overload, so the obvious shortcut does not
  exist and the overlay is the honest way to do it.
- Install actions done by hand: `File`/`Nsis7z` extract, Start-Menu + Startup +
  optional desktop `CreateShortCut`, `WriteUninstaller`, full
  `HKLM\...\Uninstall\NOBODY` key (`DisplayVersion`, `InstallLocation`,
  `EstimatedSize`, `InstallLanguage`), no firewall rule, `Exec` on Finish.
  `Section "install"` keeps `Setup.exe /S` working for the MSI/enterprise path.
- Upgrade path V1.4.0 → V1.5.0: version read from the registry at `.onInit`,
  running instance closed via `nsProcess`, `$INSTDIR` replaced,
  `%APPDATA%\NOBODY` **never touched**. `deleteAppDataOnUninstall: false`, and
  the uninstaller asks before removing user data.
- Uninstaller: same chrome, confirm → progress → farewell, removes Start-Menu
  folder, desktop + Startup shortcuts, both registry keys, `$INSTDIR`, and
  optionally `%APPDATA%\NOBODY` only when the user says so.

**3. Asset pipeline.** `build/installer-assets/generate.mjs`
(icon → two dominant colours via a 5-bit RGB histogram with a minimum hue
separation, so we never pick pink + dark pink), art at 100/125/150% DPI
(`logo`, `wallplate`, `glyphs`, `overlay`), and the four subset fonts renamed
to `NB Display / NB UI / NB FA / NB Mono` so a system copy of Inter cannot
change the typography. `prepare.mjs` fetches `Nsis7z` + `nsProcess` with pinned
SHA-256 digests.

**4. Preview harness (this repo's web build).** Because `makensis` is not
available here, the *same* spec was implemented as a running, interactive
preview — five installer pages, the three uninstaller pages, four languages with
a real mirrored layout, three DPI scales, 1366×768 floor, simulated upgrade
path, keyboard navigation, and the deliverable sources viewable/copyable from
inside the harness. Fonts for it are produced by `scripts/fetch-fonts.mjs`
(325 kB of inline woff2 subsets — Michroma / Inter / Vazirmatn / JetBrains Mono).
**The progress numbers in the harness are simulated**; the label says so.

### QA — what was actually run here

| Item | Status |
| --- | --- |
| Harness build (`npm run build`) | ✅ ran, output verified. |
| 4 languages, Farsi mirrored layout | ✅ exercised in-browser. |
| DPI 100 / 125 / 150 %, 1366×768 floor | ✅ simulated via the QA panel (window scales, nothing clips, nothing reflows mid-animation). |
| Keyboard ESC / Tab / Enter | ✅ implemented and exercised in-browser. |
| Motion limited to transform/opacity | ✅ by construction (no animated `width`/`top` anywhere). |
| Windows light/dark theme | ✅ irrelevant by construction — every colour is our own, nothing reads the system theme. |
| Path with spaces / Unicode / > MAX_PATH | ⚠️ logic written (`${GetRoot}`, quoted `UninstallString`, write-test before install, `ManifestLongPathAware`) but **not executed on Windows**. |
| Real compile of `installer.nsi` | ❌ **BLOCKED — no NSIS in this environment.** |
| Real V1.4.0 → V1.5.0 upgrade on a dirty machine | ❌ **BLOCKED** — needs a Windows VM with V1.4.0 installed. |
| Real `release/NOBODY-Setup-1.5.0.exe`, size < 120 MB | ❌ **BLOCKED**. Estimated from the payload manifest, not measured. |
| Clean-uninstall leftover check (regedit + Start Menu diff) | ❌ **BLOCKED**. |
| `nobody-v1.5.0-src.zip` in `upload/` | ❌ **BLOCKED** — no `upload/` directory and no source repo to zip here. |

**5. Motion pass — «پرده باز می‌شود».** The UI was correct and quiet; the brief
asked for a room you *enter*, so a full motion layer was added without touching
a single layout property:

- **Ambient, always on:** three slow drifting colour fields (`nb-drift`, 26-44s
  periods, `filter: blur(46px)`, `will-change: transform`) so `#09080B` never
  reads as a flat rectangle; 22 deterministic dust motes rising through the
  projector beam (`hash01(i)`, no `Math.random` — the visuals must not re-roll
  between launches); animated film grain on a 3-step cycle; a soft light that
  follows the pointer, throttled to one update per frame; a light travelling
  along the title-bar hairline every 6.5s.
- **Window:** entry is `nb-pop` (0.5s, spring easing, 3.5% overshoot), close is
  fade + blur, minimise is `nb-genie` (scale 0.86 + 120px drop).
- **Welcome:** the shell plays a curtain — two panels part vertically over 1s
  with a glowing seam that expands then dies — then the plumb line draws down
  (`nb-draw-y`), the wordmark lands letter by letter out of a blur with a
  stagger of 62ms, the tagline rises word by word (per-**word** for fa: splitting
  Arabic script per character breaks letter joining), then the single CTA pops
  inside two slow pulse rings.
- **License:** a scroll rail fills down the leading edge, the three-segment
  reading meter fills with scroll position, paragraph indices warm to accent as
  they pass, and the end-of-text marker draws its check with `stroke-dashoffset`.
- **Destination:** the dashed leader marches (`background-position`, 2.4s), the
  free-space figure is an odometer whose digit columns slide on a 520ms ease, a
  disk gauge sweeps to its needle, and the file layout staggers in one row per
  destination.
- **Installing (the heart):** the equalizer gained a bell envelope, a travelling
  wave so it reads as one gesture rather than twelve tweeters, a bright cap on
  each bar tip, a mirrored blurred reflection under the floor, a floor glow that
  tracks activity, and sparks leaving the tips. The bar pours in five layers —
  shimmer inside the empty track, body, a flow of dashes moving in the direction
  of travel, a 1px luminous edge, a 46px bloom. Percentage is an odometer. A
  six-phase stepper fills left to right with a breathing active dot. The current
  file swaps inside a fixed-height slot so a long path can never push the meter.
- **Finish / farewell:** a one-shot `LightBurst` — 24 thin streaks of light
  flying outward plus a radial flash, all transform — three expanding rings, the
  install path typing itself out.
- **Controls:** the primary button gets a hover shine **driven by a transition,
  not an animation** (a CSS animation fires once on mount, which is the classic
  broken shine), a click ripple seeded from the actual click point, and a 1px
  lift; the checkbox mark draws itself; the close glyph rotates 90° on hover;
  the four language pills share **one** indicator that slides between them with
  a signed translate so it also works mirrored.
- **Two real bugs found and fixed while doing this:**
  1. `nb-pop` on the window overrode the inline `transform: scale(fitScale)`
     because CSS animations beat inline styles — at 125% and 150% DPI the window
     would silently have rendered at 100%. The window is now three layers:
     drag/position → entry animation → DPI scale, each owning exactly one
     transform.
  2. `nb-type` (typewriter) animated `max-width`, which lays out on every frame.
     Replaced with `clip-path: inset()`, plus an RTL variant that reveals from
     the other side. Same fix applied to the disk-gauge needle, which animated
     `left`: it now rides a full-width carrier so the motion is a transform.
- **Accessibility:** one switch in the QA panel (plus the OS-level
  `prefers-reduced-motion`) calms every animation through a single `.nb-reduce`
  scope; the equalizer falls back to a near-flat idle line rather than stopping
  dead, so the page still reads as alive.

**6. V2 — the modern pass.** The V1 surface was correct and atmospheric but its
geometry was 2012: square edges, a single flat background, and a display face
(Michroma) whose wide techno letterforms now read as dated. V2 rebuilds the
token system and every component around soft geometry and one warm gradient.

- **Type:** display face Michroma → **Space Grotesk** (logotype + page titles
  now set in a 600 weight at 21-22px instead of all-caps small labels). Inter /
  Vazirmatn / JetBrains Mono unchanged. Payload moved 325 → 347 kB.
- **Geometry:** a real radius scale (window 16, cards 14, controls 10, pills
  999). Every button is a pill; every panel is a rounded card.
- **Colour:** a third accent `#FF7A4D` (coral) so the primary action can carry
  exactly one gradient — `135deg #FF2D78 → #FF7A4D`. Warm, on-brand, and
  deliberately not the purple-blue everyone else ships. Background went from
  one flat `#09080B` to four layered surfaces (`bg / bg2 / surface / surface2`)
  with 1px `white/7-9` hairlines instead of a solid dark line.
- **New components:** `AppTile` (the stage mark inside a rounded gradient tile
  — the modern app-icon shape, used at 26px in the titlebar, 44-58px on
  Finish/uninstall, 40px on the desktop), `Chip` (glass pill, with a breathing
  "live" variant that replaced the flat PREVIEW label), `ProgressRing`
  (gradient arc, round caps, a deliberate gap in the track just ahead of the
  arc, drop-shadow glow, odometer inside), and a **rotating conic border**
  (`.nb-conic`, `@property --nb-a`) applied to exactly one element per view —
  the decision that matters most: the Welcome CTA, the License accept button,
  the Finish button, and the danger modal.
- **Spine:** a slim progress rail down the start edge with one node per step.
  It appears from License onward — Welcome stays a clean hero page with no
  chrome at all — and its track fills as the flow advances. In Farsi it sits on
  the right edge for free, because it is placed with `inset-inline-start`.
- **Installing** became a bento: the ring card (132px) beside the equalizer
  card, both at a fixed 166px so they align, then the pour bar, the phase
  stepper, then four stat cards. The equalizer got rounded caps and a
  per-bar gradient; the readout moved from a table into cards.
- **Ambience:** new wallpaper (abstract gradient mesh, no theatre) and the
  window shadow now carries a faint pink ambient bloom.
- **Sync:** `build/installer.nsi` (NB_RADIUS 10 → 16, titlebar 44 → 52, the
  four surfaces, NB_ACCENT_3 and its COLORREF twin, and a comment explaining
  the face swap), `build/installer-assets/tokens.json` (V2 values + the radius
  scale + a `type` block recording the mapping), and `generate.mjs` (Space
  Grotesk source, rounded 14px frame path).

### Stage Summary

- **Delivered:** `build/installer.nsi` (full custom installer + custom
  uninstaller), `build/installer-assets/generate.mjs`, `prepare.mjs`,
  `tokens.json`, `scripts/afterPack-payload.mjs`,
  `scripts/fetch-fonts.mjs`, `patches/package.build.json`, `src/version.ts`,
  `VERSIONS.md`, and a spec-accurate interactive preview harness for the whole
  installer surface.
- **Not delivered (and why):** a compiled `NOBODY-Setup-1.5.0.exe` and the
  source zip — `makensis`, Wine and the source repo are all absent here. The
  honest next step on a Windows box is:
  `npm i -D @napi-rs/canvas subset-font 7zip-bin` →
  `npm run assets:installer` → `bun run electron:dist`, then run the QA table
  above for real. `installer.nsi` is written to compile clean, but it has
  **not** been through `makensis`, so expect the usual first-pass typos — that
  is exactly the loop that was impossible to close here.
- **Technical decision standing:** NSIS override (no Inno Setup fallback used).
  Reasons recorded above; nothing found that justifies switching.
