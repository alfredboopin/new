/**
 * The real deliverables, imported straight off disk with Vite's ?raw, so what
 * you read in the viewer is byte-for-byte what ships in the repo — not a copy
 * pasted into a string.
 */
import installerNsi from "../../build/installer.nsi?raw";
import generateMjs from "../../build/installer-assets/generate.mjs?raw";
import prepareMjs from "../../build/installer-assets/prepare.mjs?raw";
import tokensJson from "../../build/installer-assets/tokens.json?raw";
import afterPack from "../../scripts/afterPack-payload.mjs?raw";
import fetchFonts from "../../scripts/fetch-fonts.mjs?raw";
import pkgPatch from "../../patches/package.build.json?raw";
import versionTs from "../version.ts?raw";
import versionsMd from "../../VERSIONS.md?raw";
import worklogMd from "../../worklog.md?raw";

export interface Deliverable {
  path: string;
  kind: "nsis" | "script" | "config" | "doc";
  role: string;
  content: string;
}

export const DELIVERABLES: Deliverable[] = [
  {
    path: "build/installer.nsi",
    kind: "nsis",
    role:
      "The whole installer: five custom pages + a custom uninstaller, nsDialogs only, PNG through the GDI+ flat API, 4 languages with a real Farsi mirror, per-file progress from Nsis7z.",
    content: installerNsi,
  },
  {
    path: "build/installer-assets/generate.mjs",
    kind: "script",
    role:
      "Samples the two accent colours out of build/icon.png, renders the art set at every DPI, subsets and renames the four embedded fonts.",
    content: generateMjs,
  },
  {
    path: "build/installer-assets/prepare.mjs",
    kind: "script",
    role: "Fetches Nsis7z + nsProcess with pinned SHA-256 digests. No unpinned DLL ever enters the build.",
    content: prepareMjs,
  },
  {
    path: "build/installer-assets/tokens.json",
    kind: "config",
    role: "Machine-written theme tokens: accent1 #FF2D78, accent2 #FF9EC4, window geometry, motion timings.",
    content: tokensJson,
  },
  {
    path: "scripts/afterPack-payload.mjs",
    kind: "script",
    role:
      "electron-builder afterPack hook: packs win-unpacked into one solid app-1.5.0.7z and writes the fallback file list with identical progress granularity.",
    content: afterPack,
  },
  {
    path: "scripts/fetch-fonts.mjs",
    kind: "script",
    role:
      "Inline base64 font subsets for this preview (Michroma / Inter / Vazirmatn / JetBrains Mono) — the mirror of what generate.mjs does for the .exe.",
    content: fetchFonts,
  },
  {
    path: "patches/package.build.json",
    kind: "config",
    role:
      "Merge target for package.json: version 1.5.0, nsis.script, afterPack hook, MSI target left untouched.",
    content: pkgPatch,
  },
  {
    path: "src/version.ts",
    kind: "config",
    role: "APP_VERSION 1.5.0 · INSTALLER_SPEC 5, plus the merge note about not breaking existing imports.",
    content: versionTs,
  },
  {
    path: "VERSIONS.md",
    kind: "doc",
    role: "V1.5.0 entry: what was added, what changed, what is explicitly preserved.",
    content: versionsMd,
  },
  {
    path: "worklog.md",
    kind: "doc",
    role:
      "Task ID / Work Log / Stage Summary, including every verification this environment could not perform.",
    content: worklogMd,
  },
];
