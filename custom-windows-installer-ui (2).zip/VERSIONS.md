# VERSIONS

## V1.5.0 — «ورود به تاریکی» (2026-01-14)

**Theme:** the installer becomes the fifth face of the app.

### Added
- **Custom Windows Setup** (`build/installer.nsi`): electron-builder now points
  `nsis.script` at a hand-written script. No MUI2 wizard, no Windows caption,
  no default buttons — five pages built with `nsDialogs` from scratch:
  Welcome → License → Destination → Installing → Finish.
- **Custom uninstaller** in the same visual language: confirm → progress →
  farewell («NOBODY رفت… ولی برمی‌گردی، می‌دونیم 😏», localised in 4 languages).
- **PNG art through GDI+**: every bitmap is loaded with
  `GdipCreateBitmapFromFile` + `GdipCreateHBITMAPFromBitmap` through the
  GDI+ flat API (`System.dll`), composited on `#09080B` — no BMP conversion,
  no jagged edges, no skinning plugin.
- **Real progress**: the payload ships as one solid `app-1.5.0.7z`
  (`scripts/afterPack-payload.mjs`) extracted with
  `Nsis7z::ExtractWithFileCallback`, so the 12-bar equalizer and the
  current-file readout are driven by actual bytes, not by a timer.
- **Installer i18n** — fa / en / tr / ru via `LangString`, Farsi performs a
  genuine layout mirror (`SetProcessDefaultLayout` + `WS_EX_LAYOUTRTL` +
  mirrored logotype), first guess from `GetUserDefaultUILanguage()`.
- **Borderless window** with our own min/close, drag surface, rounded corners,
  `ManifestDPIAware` + long-path aware, correct at 100% / 125% / 150%.
- **Asset pipeline** (`build/installer-assets/generate.mjs`): the two accent
  colours are machine-sampled from `build/icon.png` into `tokens.json`; art and
  the four subset fonts (`NB Display`, `NB UI`, `NB FA`, `NB Mono`) are
  generated at every DPI scale and renamed so a system copy of Inter can never
  change our typography.
- **QA harness** for the installer surface, shipped as a build-time preview
  (`npm run dev` → installer preview) covering the five pages, the uninstaller,
  the four languages, the three DPI scales and the 1366×768 floor.

- **Motion layer** across every page: curtain reveal, per-glyph wordmark,
  drifting aurora fields, deterministic dust, pointer spotlight, travelling
  hairline light, equalizer with reflection/caps/sparks, five-layer pouring bar,
  odometer counters, six-phase stepper, one-shot light burst, hover shine driven
  by transitions, and a single `.nb-reduce` switch that calms all of it.
  Transform/opacity only — the typewriter was moved off `max-width` onto
  `clip-path` and the disk-gauge needle off `left` onto a transform for exactly
  that reason.

### Changed
- **V2 visual system** (second pass over the same surface): display face
  Michroma → Space Grotesk; a real radius scale (16/14/10/999) so buttons are
  pills and panels are rounded cards; four layered surface colours with
  white hairlines instead of one flat background; a third accent (`#FF7A4D`)
  giving the primary action a single warm pink→coral gradient; `AppTile`,
  `Chip`, `ProgressRing` and a rotating conic border (one per view, on the
  decision that matters); a slim step spine that grows in from License onward;
  the installing page rebuilt as a bento with the ring beside the equalizer;
  a new abstract gradient-mesh wallpaper. NSIS tokens, radii and the asset
  generator were synced to match.
- `package.json`: version `1.5.0`, `nsis.script` added, `afterPack` hook added,
  `deleteAppDataOnUninstall: false` (the uninstaller asks, it never decides).
- `src/version.ts`: `APP_VERSION 1.5.0`, `INSTALLER_SPEC 5`.
- MSI target untouched — still the second target, unchanged behaviour.

### Preserved
- `src/**` (the player) is not modified, other than the version constant.
- User data (`%APPDATA%\NOBODY`) is never written by setup and is only removed
  by the uninstaller when the user explicitly unticks "keep my data".
- Silent install `Setup.exe /S` still works (see `Section "install"`), so
  enterprise deployment and the MSI path keep the same contract.

---

## V1.4.0
(Before this entry the installer was electron-builder's default NSIS wizard.)
